library(testthat)
library(Luminescence)

test_check("Luminescence")
