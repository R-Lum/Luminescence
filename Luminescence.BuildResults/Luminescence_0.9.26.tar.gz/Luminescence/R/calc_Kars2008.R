calc_Kars2008 <- function(fit.method = "EXP", ...) {
  # nocov start
  .Defunct("calc_Huntley2006")
  calc_Huntley2006(fit.method = fit.method, ...)
  # nocov end
}
