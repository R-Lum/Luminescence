# Tracking of developement branch to integrate new function by M.A. and S.R. 

## `BaseDateSet.Conversion.rda`
* Replace existing `BaseDateSet.Conversion.rda` by new version
* Update dataset documentation 
* Correct wrong publication year `Cresswelletal2019` >> `Cresswelletal2018`
* Compress dataset with `xz` to reduce file size
* Update `scale_GammaDose()`

## `BaseDateSet.GrainSizeAttenuation.rda`
* Add dataset to package
* Rename from `GSA` to `BaseDataSet.GrainSizeAttenuation`
* Add documentation
* Add news

## `convert_Concentration2DoseRate()`
* Add function to package
* Add integrity tests + RLum.Results return
* Slight code polish
* Add alternative template output if input is missing
* Add docu from Svenja and Martin >> reformat
* Add further mandatory documentation
* Add running example
* Add unit tests 
* Fix bug for quartz: object 'data' was never created by the function, the 
conversion did not work
* Add new stop for input data with more than one row, which is not supported
by the function

## `calc_CobbleDoseRate()`

* Add function to the package
* Code reformating 
* Remove the majour condition and replace it by 'stop'
* Change the output object to RLum.Results and a list
* Add further mandatory documentation 
* Add news
* Add basic example to function
* Write basic CI test

## `ExampleData.CobbleData` 
* Add dataset to the package 
* Add minimum documentation 
